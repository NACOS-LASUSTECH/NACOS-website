const { Router } = require('express');
const KorapayService = require('../services/korapay.service.js');
const db = require('../db.js');
const protect = require('../middleware/auth.middleware.js');
const emailService = require('../services/email.service.js');

const router = Router();

/**
 * Payment Routes
 * ---------------------------------------------------------
 */

// Kick off a payment
router.post('/initialize', protect, async (req, res) => {
  const { email, amount } = req.body;

  try {
    const reference = `NACOS-${req.user.matric}-${Date.now()}`;
    const paymentData = await KorapayService.initializeTransaction({
      email,
      amount,
      reference,
      full_name: req.user.name,
      metadata: { studentId: req.user.id, matric: req.user.matric }
    });

    await db.query(
      'INSERT INTO payments (student_id, amount, reference, status, payment_type) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, amount, reference, 'pending', 'dues']
    );

    const formattedData = {
      ...paymentData,
      data: {
        ...paymentData.data,
        authorization_url: paymentData.data.checkout_url
      }
    };

    res.json(formattedData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Verify the payment
router.get('/verify/:reference', protect, async (req, res) => {
  const { reference } = req.params;

  try {
    const verificationData = await KorapayService.verifyTransaction(reference);
    
    if (verificationData.status === 'success' && (verificationData.data.status === 'success' || verificationData.data.status === 'captured')) {
      await db.query('UPDATE payments SET status = "success" WHERE reference = ?', [reference]);
      await db.query('UPDATE students SET dues_status = "Paid" WHERE id = ?', [req.user.id]);
      await db.query('INSERT INTO activities (student_id, type, status) VALUES (?, ?, ?)', [req.user.id, 'Dues Payment', 'Done']);

      emailService.sendPaymentReceipt(req.user.email, req.user.name, {
        amount: verificationData.data.amount,
        reference: reference,
        type: 'NACOS Session Dues',
      }).catch(err => console.error('Receipt Error:', err));

      emailService.sendPaymentNotificationToAdmin({
        amount: verificationData.data.amount,
        reference: reference,
        type: 'NACOS Session Dues',
      }, {
        full_name: req.user.name,
        matric_number: req.user.matric
      }).catch(err => console.error('Admin Payment Notification Error:', err));
    }

    res.json(verificationData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Korapay Webhook
router.post('/webhook', async (req, res) => {
  const { event, data } = req.body;
  
  if (event === 'charge.success') {
    const reference = data.reference;
    try {
      const [payments] = await db.query('SELECT * FROM payments WHERE reference = ?', [reference]);
      if (payments.length > 0 && payments[0].status !== 'success') {
        const studentId = payments[0].student_id;
        await db.query('UPDATE payments SET status = "success" WHERE reference = ?', [reference]);
        await db.query('UPDATE students SET dues_status = "Paid" WHERE id = ?', [studentId]);
        await db.query('INSERT INTO activities (student_id, type, status) VALUES (?, ?, ?)', [studentId, 'Dues Payment (Webhook)', 'Done']);

        const [students] = await db.query('SELECT full_name, email, matric_number FROM students WHERE id = ?', [studentId]);
        if (students.length > 0) {
          const student = students[0];
          emailService.sendPaymentReceipt(student.email, student.full_name, {
            amount: data.amount,
            reference: reference,
            type: 'NACOS Session Dues',
          }).catch(err => console.error('Webhook Receipt Error:', err));

          emailService.sendPaymentNotificationToAdmin({
            amount: data.amount,
            reference: reference,
            type: 'NACOS Session Dues',
          }, {
            full_name: student.full_name,
            matric_number: student.matric_number
          }).catch(err => console.error('Webhook Admin Payment Notification Error:', err));
        }
      }
    } catch (error) {
      console.error('❌ Webhook Processing Error:', error);
    }
  }
  res.status(200).send('Webhook Received');
});

module.exports = router;
