const { Router } = require('express');
const db = require('../db.js');
const protect = require('../middleware/auth.middleware.js');
const fs = require('fs/promises');
const path = require('path');
const upload = require('../middleware/upload.middleware.js');

const router = Router();

/**
 * Student Routes
 * ---------------------------------------------------------
 */

// Get Profile
router.get('/profile', protect, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, full_name, matric_number, level, email, dues_status, wallet_balance, profile_image FROM students WHERE id = ?',
      [req.user.id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'User not found!' });
    }

    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching profile.' });
  }
});

// Get Dashboard Overview
router.get('/dashboard', protect, async (req, res) => {
  try {
    const [studentRows] = await db.query(
      'SELECT full_name, level, email, dues_status, id_card_status, wallet_balance, attendance_percentage, resources_count, profile_image, matric_number FROM students WHERE id = ?',
      [req.user.id]
    );

    if (studentRows.length === 0) {
      return res.status(404).json({ message: 'User not found!' });
    }

    const [activityRows] = await db.query(
      'SELECT type, status, activity_date FROM activities WHERE student_id = ? ORDER BY activity_date DESC LIMIT 5',
      [req.user.id]
    );

    res.json({
      profile: studentRows[0],
      activities: activityRows
    });
  } catch (error) {
    console.error('❌ Dashboard Fetch Error:', error);
    res.status(500).json({ message: 'Error fetching dashboard data.' });
  }
});

// Update Profile Picture
router.put('/profile-image', protect, upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No image uploaded!' });
  }

  try {
    const uploadsDir = path.join(__dirname, '..', 'uploads', 'profiles');
    await fs.mkdir(uploadsDir, { recursive: true });

    const filename = `student-${req.user.id}-${Date.now()}.webp`;
    const filepath = path.join(uploadsDir, filename);

    // Try to use sharp for compression, but fallback if it's missing (CPanel issues)
    try {
      const sharp = require('sharp');
      await sharp(req.file.buffer)
        .resize(500, 500, { fit: 'cover' })
        .webp({ quality: 80 })
        .toFile(filepath);
    } catch (sharpError) {
      console.log('⚠️ Sharp not available, saving raw image as fallback');
      const rawFilename = `student-${req.user.id}-${Date.now()}-${req.file.originalname}`;
      const rawFilepath = path.join(uploadsDir, rawFilename);
      await fs.writeFile(rawFilepath, req.file.buffer);
      
      const imageUrl = `/uploads/profiles/${rawFilename}`;
      await db.query('UPDATE students SET profile_image = ? WHERE id = ?', [imageUrl, req.user.id]);
      await db.query('INSERT INTO activities (student_id, type, status) VALUES (?, ?, ?)', [req.user.id, 'Photo Update', 'Done']);
      
      return res.json({ message: 'Profile picture updated (uncompressed)!', imageUrl });
    }

    const imageUrl = `/uploads/profiles/${filename}`;
    await db.query('UPDATE students SET profile_image = ? WHERE id = ?', [imageUrl, req.user.id]);
    await db.query('INSERT INTO activities (student_id, type, status) VALUES (?, ?, ?)', [req.user.id, 'Photo Update', 'Done']);

    res.json({ message: 'Profile picture updated successfully!', imageUrl });
  } catch (error) {
    console.error('❌ Upload Error:', error);
    res.status(500).json({ message: 'Error processing image.' });
  }
});

// Update Profile
router.put('/profile', protect, async (req, res) => {
  const { full_name, level, email } = req.body;
  
  try {
    await db.query(
      'UPDATE students SET full_name = ?, level = ?, email = ? WHERE id = ?',
      [full_name, level, email, req.user.id]
    );

    await db.query('INSERT INTO activities (student_id, type, status) VALUES (?, ?, ?)', [req.user.id, 'Profile Update', 'Done']);

    res.json({ message: 'Profile updated successfully! Lookin\' good.' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating profile.' });
  }
});

// Get my payments
router.get('/payments', protect, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM payments WHERE student_id = ? ORDER BY created_at DESC', [req.user.id]);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching payments.' });
  }
});

module.exports = router;
