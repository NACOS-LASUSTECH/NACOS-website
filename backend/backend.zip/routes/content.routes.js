const { Router } = require('express');
const db = require('../db.js');

const router = Router();

/**
 * Content Routes
 * ---------------------------------------------------------
 */

// Get Executives
router.get('/executives', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM executives ORDER BY id ASC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching executives.' });
  }
});

// Get Events
router.get('/events', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM events ORDER BY event_date DESC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching events.' });
  }
});

// Get Blogs
router.get('/blogs', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM blogs ORDER BY published_at DESC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching blogs.' });
  }
});

module.exports = router;
