const { Router } = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../db.js');
const emailService = require('../services/email.service.js');
const protect = require('../middleware/auth.middleware.js');

const router = Router();

/**
 * Auth Routes
 * ---------------------------------------------------------
 */

// Login Route
router.post('/login', async (req, res) => {
  const { matric_number, password } = req.body;

  if (!matric_number || !password) {
    return res.status(400).json({ message: 'Matric number and password please!' });
  }

  try {
    const [rows] = await db.query('SELECT * FROM students WHERE matric_number = ?', [matric_number]);
    const user = rows[0];

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials. Double check that matric number!' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials. Wrong password, buddy.' });
    }

    const token = jwt.sign(
      { id: user.id, matric: user.matric_number, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    res.json({
      status: 'success',
      token,
      user: {
        id: user.id,
        name: user.full_name,
        matric_number: user.matric_number,
        level: user.level,
        role: user.role,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error during login: ' + error.message });
  }
});

// Forgot Password Route
router.post('/forgot-password', async (req, res) => {
  const { matric_number } = req.body;

  if (!matric_number) {
    return res.status(400).json({ message: 'Please provide your matric number.' });
  }

  try {
    const [rows] = await db.query('SELECT * FROM students WHERE matric_number = ?', [matric_number]);
    const student = rows[0];

    if (!student) {
      return res.status(404).json({ message: 'No account found with this matric number.' });
    }

    if (!student.email) {
      return res.status(400).json({ message: 'No email associated with this account. Please contact the admin to update your email.' });
    }

    const tempPassword = Math.random().toString(36).slice(-8);
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(tempPassword, salt);

    await db.query('UPDATE students SET password = ? WHERE id = ?', [hashedPassword, student.id]);

    await emailService.sendPasswordReset(student.email, student.full_name, tempPassword);

    res.json({ status: 'success', message: 'A temporary password has been sent to your registered email. Please check your inbox and spam folder!' });
  } catch (error) {
    console.error('Forgot Password Error:', error);
    res.status(500).json({ message: 'Error processing password reset.' });
  }
});

// Change Password Route (Requires Auth)
router.post('/change-password', protect, async (req, res) => {
  const { current_password, new_password } = req.body;

  if (!current_password || !new_password) {
    return res.status(400).json({ message: 'Both current and new passwords are required.' });
  }

  try {
    const [rows] = await db.query('SELECT password FROM students WHERE id = ?', [req.user.id]);
    const student = rows[0];

    const isMatch = await bcrypt.compare(current_password, student.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Current password is incorrect.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(new_password, salt);
    await db.query('UPDATE students SET password = ? WHERE id = ?', [hashedPassword, req.user.id]);

    res.json({ status: 'success', message: 'Password updated successfully!' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating password.' });
  }
});

module.exports = router;
