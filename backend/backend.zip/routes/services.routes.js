const { Router } = require('express');
const db = require('../db.js');
const protect = require('../middleware/auth.middleware.js');
const https = require('https');

const router = Router();

/**
 * ID Card Service Routes
 * ---------------------------------------------------------
 */

// Request a new ID Card
router.post('/id-card/request', protect, async (req, res) => {
  const { 
    passport_url, 
    full_name, 
    matric_number, 
    blood_group, 
    birthday, 
    emergency_contact 
  } = req.body;

  if (!passport_url || !full_name || !matric_number) {
    return res.status(400).json({ message: 'Missing required fields for ID card request.' });
  }

  try {
    const [existing] = await db.query('SELECT id FROM id_card_requests WHERE student_id = ?', [req.user.id]);
    
    if (existing.length > 0) {
      await db.query(
        'UPDATE id_card_requests SET passport_url = ?, full_name = ?, matric_number = ?, blood_group = ?, birthday = ?, emergency_contact = ?, status = "pending" WHERE student_id = ?',
        [passport_url, full_name, matric_number, blood_group, birthday, emergency_contact, req.user.id]
      );
    } else {
      await db.query(
        'INSERT INTO id_card_requests (student_id, passport_url, full_name, matric_number, blood_group, birthday, emergency_contact) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [req.user.id, passport_url, full_name, matric_number, blood_group, birthday, emergency_contact]
      );
    }

    await db.query('UPDATE students SET id_card_status = "Pending" WHERE id = ?', [req.user.id]);

    res.json({
      status: 'success',
      message: 'ID Card request submitted successfully!'
    });
  } catch (error) {
    console.error('❌ ID Card Request Error:', error);
    res.status(500).json({ message: 'Error submitting ID card request.' });
  }
});

// Proxy to External NACOS ID Portal
router.get('/id-card/status', protect, async (req, res) => {
  const matric = req.user.matric;
  const targetUrl = `https://nacosid.tmb.it.com/api/verify/${matric}`;

  https.get(targetUrl, (response) => {
    let data = '';
    response.on('data', (chunk) => { data += chunk; });
    response.on('end', async () => {
      try {
        const parsedData = JSON.parse(data);
        if (parsedData.status === 'success') {
          await db.query('UPDATE students SET id_card_status = "Ready" WHERE id = ?', [req.user.id]);
          return res.json({
            status: 'success',
            verified: true,
            data: parsedData.details
          });
        }
        res.json({ status: 'success', verified: false, message: 'Not found on portal.' });
      } catch (e) {
        res.json({ status: 'success', verified: false, local: true });
      }
    });
  }).on('error', async (err) => {
    const [rows] = await db.query('SELECT id_card_status FROM students WHERE id = ?', [req.user.id]);
    res.json({
      status: 'success',
      verified: false,
      local_status: rows[0]?.id_card_status || 'Not Registered'
    });
  });
});

module.exports = router;
