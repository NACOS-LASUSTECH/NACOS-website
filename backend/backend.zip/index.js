const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const dotenv = require('dotenv');
const rateLimit = require('express-rate-limit');
const path = require('path');

// Pulling in our environment variables
dotenv.config();

const db = require('./db.js');
const paymentRoutes = require('./routes/payment.routes.js');
const authRoutes = require('./routes/auth.routes.js');
const studentRoutes = require('./routes/student.routes.js');
const contentRoutes = require('./routes/content.routes.js');
const servicesRoutes = require('./routes/services.routes.js');
const contactRoutes = require('./routes/contact.routes.js');
const adminRoutes = require('./routes/admin.routes.js');

const app = express();
const PORT = process.env.PORT || 5000;

/**
 * SECURITY RATE LIMITING
 * ---------------------------------------------------------
 */
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: 'Too many requests from this IP, please try again after 15 minutes.'
});

const authLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: 'Too many login attempts. Take a break and try again later.'
});

/**
 * MIDDLEWARE SETUP
 * ---------------------------------------------------------
 */
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors());
app.use(express.json({ limit: '10kb' }));
app.use(morgan('dev'));
app.use(limiter);

/**
 * THE CORE ROUTES
 * ---------------------------------------------------------
 */
app.use('/auth', authLimiter, authRoutes);
app.use('/student', studentRoutes);
app.use('/content', contentRoutes);
app.use('/services', servicesRoutes);
app.use('/contact', contactRoutes);
app.use('/admin', adminRoutes);
app.use('/payments', paymentRoutes);

// Serve uploads folder statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// A simple health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'up', 
    timestamp: new Date().toISOString(),
    message: 'NACOS LASUSTECH Backend is humming along nicely.'
  });
});

/**
 * ERROR HANDLING
 * ---------------------------------------------------------
 */
app.use((err, req, res, next) => {
  console.error('🔥 CRITICAL ERROR:', err.stack);
  res.status(500).json({ 
    error: 'Internal Server Error',
    message: 'Something went sideways on our end. We are looking into it!' 
  });
});

// Fire it up!
app.listen(PORT, () => {
  console.log(`
  --------------------------------------------------
  ✨ NACOS LASUSTECH Backend Started
  🌍 Server: http://localhost:${PORT}
  🛠️  Mode: ${process.env.NODE_ENV || 'development'}
  --------------------------------------------------
  `);
});
