const fs = require('fs');
const path = require('path');
const db = require('./db.js');

/**
 * Database Initialization Script
 * ---------------------------------------------------------
 */
const init = async () => {
  try {
    console.log('🚀 Starting Database Initialization...');
    
    const sqlPath = path.resolve('setup.sql');
    const sql = fs.readFileSync(sqlPath, 'utf8');

    const statements = sql
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    for (const statement of statements) {
      console.log('📜 Executing:', statement.substring(0, 50) + '...');
      await db.query(statement);
    }

    console.log('✅ Database tables created successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Initialization failed:', error.message);
    process.exit(1);
  }
};

init();
